<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "covid_vaccine_system";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>
