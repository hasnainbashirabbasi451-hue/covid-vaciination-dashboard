<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>COVID Test & Vaccination System</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    /* Reset */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Inter', sans-serif;
      background: linear-gradient(135deg, #032326, #66a6ff);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }

    .container {
      background: rgba(31, 66, 163, 0.2);
      backdrop-filter: blur(12px);
      -webkit-backdrop-filter: blur(12px);
      border-radius: 16px;
      padding: 40px 30px;
      max-width: 700px;
      width: 100%;
      text-align: center;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
      color: #fff;
      transition: all 0.3s ease-in-out;
    }

    .container:hover {
      transform: scale(1.02);
    }

    h1 {
      font-size: 2.5rem;
      margin-bottom: 30px;
      font-weight: 700;
    }

    nav ul {
      list-style: none;
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 15px;
    }

    nav ul li a {
      display: inline-block;
      padding: 14px 24px;
      background: #ffffff33;
      color: #fff;
      text-decoration: none;
      font-weight: 600;
      border-radius: 8px;
      transition: all 0.3s ease;
      border: 1px solid rgba(255, 255, 255, 0.3);
      backdrop-filter: blur(5px);
    }

    nav ul li a:hover {
      background: #fff;
      color: #007bff;
      transform: translateY(-2px);
    }

    @media (max-width: 600px) {
      .container {
        padding: 30px 20px;
      }

      nav ul {
        flex-direction: column;
        gap: 12px;
      }

      nav ul li a {
        width: 100%;
        text-align: center;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Welcome to COVID Test & Vaccination System</h1>
    <nav>
      <ul>
        <li><a href="admin/dashboard.php">Admin Login</a></li>
        <li><a href="hospital/login.php">Hospital Login</a></li>
        <li><a href="hospital/register.php">Hospital Register</a></li>
        <li><a href="patient/login.php">Patient Login</a></li>
        <li><a href="patient/register.php">Patient Register</a></li>
      </ul>
    </nav>
  </div>
</body>
</html>
