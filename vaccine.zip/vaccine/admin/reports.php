<?php 
session_start();
include('../config/db.php');

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

include('../config/db.php'); // Adjust if db.php is elsewhere

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $report = $_FILES['report'];

    // Check or insert patient
    $stmt = $conn->prepare("SELECT id FROM patient WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 0) {
        $conn->query("INSERT INTO patient (name, email) VALUES ('Unknown', '$email')");
        $patient_id = $conn->insert_id;
    } else {
        $row = $res->fetch_assoc();
        $patient_id = $row['id'];
    }


    $filename = time() . '_' . basename($report['name']);
    $target = "../reports/" . $filename;
    move_uploaded_file($report["tmp_name"], $target);

    // Insert into covid_reports table
    $stmt = $conn->prepare("INSERT INTO covid_reports (patient_id, report_file) VALUES (?, ?)");
    $stmt->bind_param("is", $patient_id, $filename);
    $stmt->execute();

    echo "<script>alert('Report uploaded successfully.'); window.location.href='reports.php';</script>";
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>COVID-19 Reports</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #071213, #66a6ff);
            height: 100vh;
            display: flex;
            align-items: stretch;
        }

        .container {
            display: flex;
            flex: 1;
        }

        /* Sidebar styles */
        .sidebar {
            width: 240px;
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(14px);
            -webkit-backdrop-filter: blur(14px);
            padding: 30px 20px;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
            color: white;
            border-right: 1px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar h1 {
            font-size: 1.6rem;
            font-weight: 700;
            text-align: center;
            margin-bottom: 30px;
        }

        .sidebar ul {
            list-style: none;
        }

        .sidebar ul li {
            margin-bottom: 12px;
        }

        .sidebar ul li a {
            display: block;
            padding: 12px 18px;
            text-decoration: none;
            color: white;
            font-weight: 600;
            border-left: 4px solid transparent;
            border-radius: 6px;
            transition: all 0.3s ease;
            background-color: rgba(255, 255, 255, 0.1);
        }

        .sidebar ul li a:hover,
        .sidebar ul li a.active {
            background-color: #ffffff;
            color: #007bff;
            border-left: 4px solid #ffc107;
            transform: translateX(4px);
        }

        /* Main content area */
        main {
            flex: 1;
            padding: 50px;
            background-color: #f7faff;
            overflow-y: auto;
            color: #333;
        }

        main h1 {
            font-size: 2rem;
            margin-bottom: 20px;
        }

        main p {
            font-size: 1.1rem;
            margin-bottom: 30px;
            color: #555;
        }

        .btn {
            display: inline-block;
            padding: 12px 24px;
            background: rgba(0, 123, 255, 0.1);
            color: #007bff;
            font-weight: 600;
            text-decoration: none;
            border-radius: 8px;
            border: 1px solid #007bff;
            transition: all 0.3s ease;
        }

        .btn:hover {
            background: #007bff;
            color: #fff;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                position: fixed;
                width: 100%;
                height: auto;
                bottom: 0;
                left: 0;
                display: flex;
                flex-direction: row;
                justify-content: space-around;
                padding: 10px;
                z-index: 100;
            }

            .sidebar h1 {
                display: none;
            }

            .sidebar ul {
                display: flex;
                gap: 10px;
                flex-wrap: wrap;
            }

            .sidebar ul li {
                margin-bottom: 0;
            }

            .sidebar ul li a {
                font-size: 0.9rem;
                padding: 10px 14px;
                border-left: none;
            }

            main {
                padding: 30px 20px;
                margin-bottom: 80px;
            }
        }
        main {
    flex: 1;
    padding: 50px;
    background: linear-gradient(135deg, #f7faff, #e3f2fd);
    overflow-y: auto;
    color: #333;
    border-radius: 20px;
    box-shadow: 0 10px 40px rgba(0, 0, 0, 0.05);
    margin: 30px;
}

main h1 {
    font-size: 2.2rem;
    margin-bottom: 10px;
    font-weight: 700;
    color: #003366;
}

main p {
    font-size: 1.1rem;
    margin-bottom: 30px;
    color: #555;
}

form {
    background: white;
    padding: 30px 40px;
    border-radius: 16px;
    box-shadow: 0 12px 30px rgba(0, 0, 0, 0.1);
    max-width: 500px;
    margin-bottom: 40px;
}

form h3 {
    font-size: 1.5rem;
    margin-bottom: 20px;
    color: #007bff;
}

form label {
    font-weight: 600;
    display: block;
    margin-bottom: 8px;
    color: #333;
}

form input[type="email"],
form input[type="file"] {
    width: 100%;
    padding: 12px 14px;
    border: 1px solid #ccc;
    border-radius: 8px;
    font-size: 1rem;
    margin-bottom: 20px;
    transition: border 0.3s ease;
}

form input:focus {
    border-color: #007bff;
    outline: none;
}

.btn {
    display: inline-block;
    padding: 12px 24px;
    background: linear-gradient(135deg, #007bff, #0056b3);
    color: #fff;
    font-weight: 600;
    text-decoration: none;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 6px 20px rgba(0, 123, 255, 0.3);
}

.btn:hover {
    background: linear-gradient(135deg, #0056b3, #003f7f);
    color: #fff;
    transform: translateY(-1px);
}

@media (max-width: 768px) {
    main {
        padding: 20px;
        margin: 10px;
    }

    form {
        padding: 20px;
    }
}

    </style>
</head>
<body>

<div class="container">
    <!-- Sidebar -->
    <nav class="sidebar">
        <h1>ADMIN PORTAL</h1>
        <ul>
                <li><a href="dashboard.php">Dashbaord</a></li>
            <li><a href="view_patients.php">View All Patients</a></li>
            <li><a href="reports.php" class="active">COVID-19 Reports</a></li>
            <li><a href="hospitals.php">Hospitals List</a></li>
            <li><a href="booking.php">Booking Details</a></li>
              <li><a href="approve_appointment.php">view patient booking</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
    <main>
        <h1>COVID-19 Reports</h1>

        <p>Here you can implement and export COVID-19 test and vaccination reports by day, week, or month.</p>
        <form action="upload_report.php" method="POST" enctype="multipart/form-data" style="margin-top: 30px;">
    <h3>Upload Report for Patient</h3>
    <label>Email:</label><br>
    <input type="email" name="email" required><br><br>

    <label>Report File (PDF):</label><br>
    <input type="file" name="report" accept="application/pdf" required><br><br>

    <button type="submit" class="btn">Upload Report</button>
</form>

        <a href="dashboard.php" class="btn">← Back to Dashboard</a>
    </main>
</div>
</body>
</html>
