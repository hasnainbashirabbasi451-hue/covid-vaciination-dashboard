<?php
session_start();
include('../config/db.php');
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM admin WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows == 1) {
        $admin = $res->fetch_assoc();
        // Password stored as SHA2 hash for simplicity
        if (hash('sha256', $password) === $admin['password']) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username'] = $username;
            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Invalid username or password";
        }
    } else {
        $error = "Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Admin Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet" />
    <style>
        /* Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #071213, #66a6ff);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(14px);
            -webkit-backdrop-filter: blur(14px);
            border-radius: 16px;
            padding: 40px 50px;
            max-width: 400px;
            width: 100%;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
            color: white;
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        h2 {
            margin-bottom: 30px;
            font-weight: 700;
            font-size: 2rem;
        }

        form {
            display: flex;
            flex-direction: column;
            text-align: left;
        }

        label {
            font-weight: 600;
            margin-bottom: 6px;
            margin-top: 20px;
            font-size: 0.95rem;
        }

        input[type="text"],
        input[type="password"] {
            padding: 12px 15px;
            border-radius: 8px;
            border: none;
            outline: none;
            font-size: 1rem;
            transition: box-shadow 0.3s ease;
            background: rgba(255, 255, 255, 0.25);
            color: white;
            font-weight: 500;
            box-shadow: inset 0 0 8px rgba(255,255,255,0.3);
        }

        input[type="text"]::placeholder,
        input[type="password"]::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            box-shadow: 0 0 8px 2px #ffc107;
            background: rgba(255, 255, 255, 0.35);
        }

        input[type="submit"] {
            margin-top: 30px;
            padding: 14px;
            border-radius: 10px;
            border: none;
            font-weight: 700;
            font-size: 1.1rem;
            cursor: pointer;
            background: #007bff;
            color: white;
            box-shadow: 0 5px 15px rgba(0,123,255,0.4);
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }

        input[type="submit"]:hover {
            background: #0056b3;
            box-shadow: 0 8px 20px rgba(0,86,179,0.7);
        }

        .error {
            background: rgba(255, 0, 0, 0.25);
            color: #ffdddd;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 600;
            box-shadow: 0 0 10px rgba(255,0,0,0.4);
        }

        @media (max-width: 480px) {
            .container {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Admin Login</h2>
        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="POST">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" placeholder="Enter your username" required />

            <label for="password">Password</label>
            <input type="password" id="password" name="password" placeholder="Enter your password" required />

            <input type="submit" value="Login" />
        </form>
    </div>
</body>
</html>
