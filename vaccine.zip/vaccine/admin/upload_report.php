<?php
include('../config/db.php'); 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $report = $_FILES['report'];

    // Check or insert patient
    $stmt = $conn->prepare("SELECT id FROM patient WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 0) {
        $conn->query("INSERT INTO patient (name, email) VALUES ('Unknown', '$email')");
        $patient_id = $conn->insert_id;
    } else {
        $row = $res->fetch_assoc();
        $patient_id = $row['id'];
    }

    // Save file
    $filename = time() . '_' . basename($report['name']);
    $target = "../reports/" . $filename;
    move_uploaded_file($report["tmp_name"], $target);

    // Insert into covid_reports table
    $stmt = $conn->prepare("INSERT INTO covid_reports (patient_id, report_file) VALUES (?, ?)");
    $stmt->bind_param("is", $patient_id, $filename);
    $stmt->execute();

    echo "<script>alert('Report uploaded successfully.'); window.location.href='reports.php';</script>";
}
?>
