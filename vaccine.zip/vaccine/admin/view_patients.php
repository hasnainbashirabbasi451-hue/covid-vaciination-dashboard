<?php
session_start();
include('../config/db.php');

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

$sql = "SELECT * FROM patient";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Admin Dashboard - All Patients</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet" />
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #071213, #66a6ff);
            height: 100vh;
            display: flex;
            align-items: stretch;
            color: #333;
        }

        .container {
            display: flex;
            flex: 1;
            overflow: hidden;
        }

        .sidebar {
            width: 240px;
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(12px);
            padding: 30px 20px;
            color: white;
            border-right: 1px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar h1 {
            font-size: 1.6rem;
            font-weight: 700;
            text-align: center;
            margin-bottom: 30px;
        }

        .sidebar ul {
            list-style: none;
        }

        .sidebar ul li {
            margin-bottom: 12px;
        }

        .sidebar ul li a {
            display: block;
            padding: 12px 18px;
            text-decoration: none;
            color: white;
            font-weight: 600;
            border-left: 4px solid transparent;
            border-radius: 6px;
            background-color: rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
        }

        .sidebar ul li a:hover,
        .sidebar ul li a.active {
            background-color: #ffffff;
            color: black;
            border-left: 4px solid #ffc107;
            transform: translateX(4px);
        }

        main {
            flex: 1;
            padding: 40px;
            background-color: #f7faff;
            overflow-y: auto;
        }

        main h1 {
            font-weight: 700;
            font-size: 2rem;
            margin-bottom: 25px;
            color: #0a1f44;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
            overflow: hidden;
        }

        th, td {
            padding: 14px 20px;
            text-align: left;
            font-weight: 500;
            border-bottom: 1px solid #e0e4f0;
            color: #0a1f44;
        }

        th {
            background: #66a6ff;
            color: white;
            text-transform: uppercase;
        }

        tr:hover {
            background-color: #d9e8ff;
        }

        a.back-link {
            display: inline-block;
            margin-top: 30px;
            padding: 12px 22px;
            background: #007bff;
            color: white;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
        }

        a.back-link:hover {
            background: #0056b3;
        }

        .delete-btn {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
        }

        .delete-btn:hover {
            background-color: #b02a37;
        }

        @media (max-width: 768px) {
            .sidebar {
                position: fixed;
                width: 100%;
                height: auto;
                bottom: 0;
                left: 0;
                flex-direction: row;
                justify-content: space-around;
                padding: 10px;
                z-index: 100;
            }

            .sidebar h1 {
                display: none;
            }

            .sidebar ul {
                display: flex;
                gap: 10px;
            }

            .sidebar ul li {
                margin-bottom: 0;
            }

            .sidebar ul li a {
                font-size: 0.9rem;
                padding: 10px 14px;
                border-left: none;
            }

            main {
                margin-bottom: 80px;
                padding: 20px;
            }

            table, th, td {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <nav class="sidebar">
        <h1>ADMIN PORTAL</h1>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="view_patients.php" class="active">View All Patients</a></li>
            <li><a href="reports.php">COVID-19 Reports</a></li>
            <li><a href="hospitals.php">Hospitals List</a></li>
            <li><a href="booking.php">Booking Details</a></li>
             <li><a href="approve_appointment.php">View patient booking</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
    <main>
        <h1>All Patient Profiles</h1>

        <?php if (isset($_GET['deleted']) && $_GET['deleted'] == 1): ?>
            <div style="background-color: #d4edda; color: #155724; padding: 12px; margin-bottom: 20px; border-radius: 6px;">
                Patient deleted successfully.
            </div>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>Name</th><th>Email</th><th>Address</th><th>Location</th><th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <td><?= htmlspecialchars($row['address']) ?></td>
                    <td><?= htmlspecialchars($row['location']) ?></td>
                    <td>
                        <form method="POST" action="delete_patient.php" onsubmit="return confirm('Are you sure you want to delete this patient?');">
                            <input type="hidden" name="patient_id" value="<?= $row['id'] ?>">
                            <button type="submit" class="delete-btn">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>

        <a href="dashboard.php" class="back-link">Back to Dashboard</a>
    </main>
</div>
</body>
</html>
