<?php
session_start();
include('../config/db.php');

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

$sql = "SELECT * FROM hospital";
$result = $conn->query($sql);
?>
<style>
        /* Reset */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #071213, #66a6ff);
            height: 100vh;
            display: flex;
            align-items: stretch;
            color: #333;
        }

        .container {
            display: flex;
            flex: 1;
            overflow: hidden;
        }

        /* Sidebar */
        .sidebar {
            width: 240px;
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            padding: 30px 20px;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
            color: white;
            border-right: 1px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar h1 {
            font-size: 1.6rem;
            font-weight: 700;
            text-align: center;
            margin-bottom: 30px;
            letter-spacing: 1.2px;
        }

        .sidebar ul {
            list-style: none;
        }

        .sidebar ul li {
            margin-bottom: 12px;
        }

        .sidebar ul li a {
            display: block;
            padding: 12px 18px;
            text-decoration: none;
            color: white;
            font-weight: 600;
            border-left: 4px solid transparent;
            border-radius: 6px;
            transition: all 0.3s ease;
            background-color: rgba(255, 255, 255, 0.1);
        }

        .sidebar ul li a:hover,
        .sidebar ul li a.active {
            background-color: #ffffff;
            color: black;
            border-left: 4px solid #ffc107;
            transform: translateX(4px);
        }

        /* Mark the Hospitals List link as active */
        .sidebar ul li a[href="hospitals.php"] {
            border-left-color: #ffc107;
            background-color: #fff;
            color: black;
            transform: translateX(4px);
        }

        main {
            flex: 1;
            padding: 40px;
            background-color: #f7faff;
            overflow-y: auto;
        }

        main h1 {
            font-weight: 700;
            font-size: 2rem;
            margin-bottom: 25px;
            color: #0a1f44;
        }

        /* Table styles */
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
            overflow: hidden;
        }

        th, td {
            padding: 14px 20px;
            text-align: left;
            font-weight: 500;
            border-bottom: 1px solid #e0e4f0;
            color: #0a1f44;
        }

        th {
            background: #66a6ff;
            color: white;
            font-weight: 700;
            letter-spacing: 0.05em;
            text-transform: uppercase;
        }

        tr:hover {
            background-color: #d9e8ff;
            cursor: default;
        }

        a.back-link {
            display: inline-block;
            margin-top: 30px;
            padding: 12px 22px;
            background: #007bff;
            color: white;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: background-color 0.3s ease;
            box-shadow: 0 5px 15px rgba(0,123,255,0.4);
        }

        a.back-link:hover {
            background: #0056b3;
            box-shadow: 0 8px 20px rgba(0,86,179,0.7);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                position: fixed;
                width: 100%;
                height: auto;
                bottom: 0;
                left: 0;
                display: flex;
                flex-direction: row;
                justify-content: space-around;
                padding: 10px;
                z-index: 100;
            }

            .sidebar h1 {
                display: none;
            }

            .sidebar ul {
                display: flex;
                gap: 10px;
            }

            .sidebar ul li {
                margin-bottom: 0;
            }

            .sidebar ul li a {
                font-size: 0.9rem;
                padding: 10px 14px;
                border-left: none;
            }

            main {
                margin-bottom: 80px;
                padding: 20px;
                overflow-y: auto;
            }

            table, th, td {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <nav class="sidebar">
        <h1>ADMIN PORTAL</h1>
        <ul>
            <li><a href="dashbaord.php">Dashbaord</a></li>
            <li><a href="view_patients.php">View All Patients</a></li>
            <li><a href="reports.php">COVID-19 Reports</a></li>
            <li><a href="hospitals.php" class="active">Hospitals List</a></li>
            <li><a href="booking.php">Booking Details</a></li>
            <li><a href="approve_appointments.php">View pateint booking</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
    <main>
        <h1>Hospitals List</h1>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Location</th>
                    <th>Approved</th>
                </tr>
            </thead>
            <tbody>
            <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <td><?= htmlspecialchars($row['address']) ?></td>
                    <td><?= htmlspecialchars($row['location']) ?></td>
                    <td><?= $row['approved'] ? '<span style="color:green; font-weight:700;">Yes</span>' : '<span style="color:red; font-weight:700;">No</span>' ?></td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
        <a href="dashboard.php" class="back-link">Back to Dashboard</a>
    </main>
</div>
</body>
</html>
