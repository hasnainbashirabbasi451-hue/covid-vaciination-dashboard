<?php
session_start();
include('../config/db.php');

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #071213, #66a6ff);
            height: 100vh;
            display: flex;
            align-items: stretch;
        }

        .container {
            display: flex;
            flex: 1;
        }

        /* Sidebar styles */
        .sidebar {
            width: 240px;
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            padding: 30px 20px;
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
            color: white;
            border-right: 1px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar h1 {
            font-size: 1.6rem;
            font-weight: 700;
            text-align: center;
            margin-bottom: 30px;
        }

        .sidebar ul {
            list-style: none;
        }

        .sidebar ul li {
            margin-bottom: 12px;
        }

        .sidebar ul li a {
            display: block;
            padding: 12px 18px;
            text-decoration: none;
            color: white;
            font-weight: 600;
            border-left: 4px solid transparent;
            border-radius: 6px;
            transition: all 0.3s ease;
            background-color: rgba(255, 255, 255, 0.1);
        }

        .sidebar ul li a:hover,
        .sidebar ul li a.active {
            background-color: #ffffff;
            color: black;
            border-left: 4px solid #ffc107;
            transform: translateX(4px);
        }

        main {
            flex: 1;
            padding: 40px;
            background-color: #f7faff;
            overflow-y: auto;
            color: #333;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                position: fixed;
                width: 100%;
                height: auto;
                bottom: 0;
                left: 0;
                display: flex;
                flex-direction: row;
                justify-content: space-around;
                padding: 10px;
                z-index: 100;
            }

            .sidebar h1 {
                display: none;
            }

            .sidebar ul {
                display: flex;
                gap: 10px;
            }

            .sidebar ul li {
                margin-bottom: 0;
            }

            .sidebar ul li a {
                font-size: 0.9rem;
                padding: 10px 14px;
                border-left: none;
            }

            main {
                margin-bottom: 80px;
                padding: 20px;
            }
        }
        /* Admin Dashboard Styles */
.admin-main {
    flex: 1;
    padding: 40px;
    background-color: #f4f8fb;
    overflow-y: auto;
    color: #333;
    font-family: 'Inter', sans-serif;
}

.dashboard-heading {
    font-size: 2rem;
    font-weight: 700;
    margin-bottom: 10px;
    color: #222;
}

.dashboard-subtext {
    font-size: 1rem;
    color: #555;
    margin-bottom: 30px;
}

.dashboard-section {
    margin-top: 40px;
}

.section-title {
    font-size: 1.3rem;
    font-weight: 600;
    margin-bottom: 20px;
    color: #111;
}

.stats-grid {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
}

.stat-card {
    flex: 1 1 200px;
    background: linear-gradient(145deg, #ffffff, #e6eaf1);
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.07);
    transition: transform 0.3s ease;
}

.stat-card:hover {
    transform: translateY(-5px);
}

.stat-card h3 {
    font-size: 1.1rem;
    margin-bottom: 8px;
    color: #333;
}

.stat-number {
    font-size: 2rem;
    font-weight: 700;
    color: #007bff;
}

.pending-actions {
    list-style: disc;
    padding-left: 25px;
    margin-top: 15px;
}

.pending-actions li {
    margin-bottom: 10px;
}

.pending-actions a {
    color: #007bff;
    text-decoration: none;
    font-weight: 500;
    transition: color 0.3s ease;
}

.pending-actions a:hover {
    color: #0056b3;
    text-decoration: underline;
}

    </style>
</head>
<body>
<div class="container">
    <nav class="sidebar">
        <h1>ADMIN PORTAL</h1>
        <ul>
             <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="view_patients.php">View All Patients</a></li>
            <li><a href="reports.php">COVID-19 Reports</a></li>
            <li><a href="hospitals.php">Hospitals List</a></li>
            <li><a href="booking.php">Booking Details</a></li>
             <li><a href="approve_appointments.php">View pateint booking</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
  
            <?php
            $total_patients = $conn->query("SELECT COUNT(*) as total FROM patient")->fetch_assoc()['total'];
            $total_hospitals = $conn->query("SELECT COUNT(*) as total FROM hospital")->fetch_assoc()['total'];
            $approved_hospitals = $conn->query("SELECT COUNT(*) as total FROM hospital WHERE approved = 1")->fetch_assoc()['total'];
            $total_bookings = $conn->query("SELECT COUNT(*) as total FROM bookings")->fetch_assoc()['total'];
            $total_vaccines = $conn->query("SELECT COUNT(*) as total FROM vaccines")->fetch_assoc()['total'];
            ?>
 <main class="admin-main">
    <h1 class="dashboard-heading">Welcome, Admin!</h1>
    <p class="dashboard-subtext">This is your central dashboard. From here, you can manage hospitals, patient bookings, reports, and vaccines.</p>

    <section class="dashboard-section">
        <h2 class="section-title">Quick Stats</h2>
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Patients</h3>
                <p class="stat-number"><?= $total_patients ?></p>
            </div>
            <div class="stat-card">
                <h3>Hospitals (Approved)</h3>
                <p class="stat-number"><?= $approved_hospitals ?> / <?= $total_hospitals ?></p>
            </div>
            <div class="stat-card">
                <h3>Vaccine Types</h3>
                <p class="stat-number"><?= $total_vaccines ?></p>
            </div>
            <div class="stat-card">
                <h3>Bookings</h3>
                <p class="stat-number"><?= $total_bookings ?></p>
            </div>
        </div>
    </section>

    <section class="dashboard-section">
        <h2 class="section-title">Pending Actions</h2>
        <ul class="pending-actions">
            <li><a href="approve_appointments.php">Review and manage patient bookings</a></li>
            <li><a href="reports.php">Update or review COVID-19 reports</a></li>
        </ul>
    </section>
</main>

</div>
</body>
</html>
