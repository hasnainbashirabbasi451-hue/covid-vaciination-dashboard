<?php
session_start();
include('../config/db.php');

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve_id'])) {
    $approve_id = intval($_POST['approve_id']);
    $stmt = $conn->prepare("UPDATE bookings SET status = 'approved' WHERE id = ?");
    $stmt->bind_param("i", $approve_id);
    $message = $stmt->execute()
        ? "✅ Appointment approved successfully."
        : "❌ Failed to approve appointment.";
}

$query = "
  SELECT
    b.id, b.appointment_date, b.status,
    p.name AS patient_name,
    h.name AS hospital_name
  FROM bookings b
  JOIN patient p ON b.patient_id = p.id
  JOIN hospital h ON b.hospital_id = h.id
  WHERE b.status = 'pending'
  ORDER BY b.appointment_date ASC
";

$pending_bookings = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Approve Appointments</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Inter', sans-serif;
      background: linear-gradient(135deg, #071213, #66a6ff);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
      color: white;
    }
    .container {
      background: rgba(255, 255, 255, 0.08);
      backdrop-filter: blur(15px);
      border-radius: 16px;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.4);
      padding: 30px;
      width: 100%;
      max-width: 900px;
    }
    h2 {
      text-align: center;
      margin-bottom: 20px;
      font-size: 1.8rem;
      font-weight: 700;
      color: #ffc107;
    }
    .message {
      background: rgba(255, 255, 255, 0.2);
      padding: 12px;
      border-radius: 8px;
      margin-bottom: 20px;
      font-weight: 600;
      border-left: 4px solid #ffc107;
      color: #000;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      background: rgba(255, 255, 255, 0.12);
      border-radius: 8px;
      overflow: hidden;
      margin-bottom: 20px;
    }
    th, td {
      padding: 14px 18px;
      text-align: left;
      color: #fff;
    }
    th {
      background: rgba(0, 0, 0, 0.2);
      font-weight: 600;
    }
    tr:nth-child(even) { background: rgba(255, 255, 255, 0.05); }
    button {
      padding: 10px 16px;
      background: #ffc107;
      border: none;
      border-radius: 6px;
      font-weight: 600;
      cursor: pointer;
      transition: background-color 0.3s ease;
      color: #000;
    }
    button:hover {
      background: #e0a800;
    }
    a.back {
      display: inline-block;
      margin-top: 10px;
      color: #ffc107;
      text-decoration: none;
      font-weight: 600;
    }
    a.back:hover { text-decoration: underline; }
  </style>
</head>
<body>
  <div class="container">
    <h2>Pending Appointment Approvals</h2>
    <?php if ($message): ?>
      <div class="message"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <?php if ($pending_bookings->num_rows > 0): ?>
      <table>
        <thead>
          <tr>
            <th>Patient</th>
            <th>Hospital</th>
            <th>Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = $pending_bookings->fetch_assoc()): ?>
            <tr>
              <td><?= htmlspecialchars($row['patient_name']) ?></td>
              <td><?= htmlspecialchars($row['hospital_name']) ?></td>
              <td><?= htmlspecialchars($row['appointment_date']) ?></td>
              <td>
                <form method="POST" style="display:inline;">
                  <input type="hidden" name="approve_id" value="<?= $row['id'] ?>">
                  <button type="submit">Approve</button>
                </form>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    <?php else: ?>
      <p>No pending appointments.</p>
    <?php endif; ?>

    <a class="back" href="dashboard.php">← Back to Admin Dashboard</a>
  </div>
</body>
</html>
