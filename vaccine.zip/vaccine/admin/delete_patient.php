<?php
session_start();
include('../config/db.php');

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['patient_id'])) {
    $patient_id = intval($_POST['patient_id']);

    // Optional: Delete related reports/bookings here if needed
    // Example: $conn->query("DELETE FROM covid_reports WHERE patient_id = $patient_id");

    $stmt = $conn->prepare("DELETE FROM patient WHERE id = ?");
    $stmt->bind_param("i", $patient_id);

    if ($stmt->execute()) {
        header("Location: view_patients.php?deleted=1");
        exit;
    } else {
        echo "Error deleting patient.";
    }

    $stmt->close();
} else {
    header("Location: view_patients.php");
    exit;
}
