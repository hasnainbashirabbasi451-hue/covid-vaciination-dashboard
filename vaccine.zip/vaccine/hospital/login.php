<?php
session_start();
include('../config/db.php');
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM hospital WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows == 1) {
        $hospital = $res->fetch_assoc();

        if (!$hospital['approved']) {
            $error = "Your registration is pending admin approval.";
        } elseif (password_verify($password, $hospital['password'])) {
            $_SESSION['hospital_logged_in'] = true;
            $_SESSION['hospital_id'] = $hospital['id'];
            $_SESSION['hospital_name'] = $hospital['name'];
            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Incorrect password.";
        }
    } else {
        $error = "Email not registered.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Hospital Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet" />
    <style>
        /* Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #071213, #66a6ff);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            color: white;
        }

        .container {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(14px);
            -webkit-backdrop-filter: blur(14px);
            border-radius: 16px;
            padding: 40px 50px;
            max-width: 400px;
            width: 100%;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        h2 {
            font-weight: 700;
            font-size: 2rem;
            margin-bottom: 30px;
        }

        form {
            display: flex;
            flex-direction: column;
            text-align: left;
        }

        label {
            font-weight: 600;
            margin-bottom: 6px;
            margin-top: 20px;
            font-size: 0.95rem;
        }

        input[type="email"],
        input[type="password"] {
            padding: 12px 15px;
            border-radius: 8px;
            border: none;
            outline: none;
            font-size: 1rem;
            transition: box-shadow 0.3s ease;
            background: rgba(255, 255, 255, 0.25);
            color: white;
            font-weight: 500;
            box-shadow: inset 0 0 8px rgba(255,255,255,0.3);
        }

        input::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        input[type="email"]:focus,
        input[type="password"]:focus {
            box-shadow: 0 0 8px 2px #ffc107;
            background: rgba(255, 255, 255, 0.35);
        }

        input[type="submit"] {
            margin-top: 30px;
            padding: 14px;
            border-radius: 10px;
            border: none;
            font-weight: 700;
            font-size: 1.1rem;
            cursor: pointer;
            background: #007bff;
            color: white;
            box-shadow: 0 5px 15px rgba(0,123,255,0.4);
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }

        input[type="submit"]:hover {
            background: #0056b3;
            box-shadow: 0 8px 20px rgba(0,86,179,0.7);
        }

        .error {
            background: rgba(255, 0, 0, 0.25);
            color: #ffdddd;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 600;
            box-shadow: 0 0 10px rgba(255,0,0,0.4);
        }

        a {
            display: inline-block;
            margin-top: 25px;
            font-weight: 600;
            color: #ffc107;
            text-decoration: none;
            transition: color 0.3s ease;
            font-size: 0.95rem;
        }

        a:hover {
            color: white;
        }

        @media (max-width: 480px) {
            .container {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Hospital Login</h2>
    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST" novalidate>
        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="hospital@example.com" required />
        
        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="Enter your password" required />
        
        <input type="submit" value="Login" />
    </form>
    <a href="register.php">New hospital? Register here</a>
</div>
</body>
</html>
