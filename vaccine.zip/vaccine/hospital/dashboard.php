<?php
session_start();
include('../config/db.php');

if (!isset($_SESSION['hospital_logged_in'])) {
    header("Location: login.php");
    exit;
}

$hospital_id = $_SESSION['hospital_id'];
$hospital_name = $_SESSION['hospital_name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Hospital Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet" />
    <style>
        /* Reset and base */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #071213, #4a90e2);
            color: white;
            height: 100vh;
            display: flex;
            align-items: stretch;
        }
        .container {
            display: flex;
            flex: 1;
        }

        /* Sidebar styles */
        .sidebar {
            width: 260px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            padding: 30px 25px;
            box-shadow: 5px 0 20px rgba(0, 0, 0, 0.3);
            border-right: 1px solid rgba(255, 255, 255, 0.2);
            display: flex;
            flex-direction: column;
        }

        .sidebar h1 {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 40px;
            text-align: center;
            text-shadow: 0 0 6px rgba(255, 255, 255, 0.7);
        }

        .sidebar nav ul {
            list-style: none;
            flex-grow: 1;
        }

        .sidebar nav ul li {
            margin-bottom: 18px;
        }

        .sidebar nav ul li a {
            display: block;
            padding: 14px 20px;
            font-weight: 600;
            font-size: 1.1rem;
            color: white;
            text-decoration: none;
            border-left: 4px solid transparent;
            border-radius: 8px;
            background-color: rgba(255, 255, 255, 0.05);
            transition: 
                background-color 0.3s ease, 
                color 0.3s ease,
                border-left-color 0.3s ease,
                transform 0.2s ease;
            box-shadow: 0 0 5px transparent;
        }

        .sidebar nav ul li a:hover,
        .sidebar nav ul li a:focus {
            background-color: rgba(255, 255, 255, 0.25);
            color: #071213;
            border-left-color: #ffc107;
            transform: translateX(6px);
            box-shadow: 0 4px 15px rgba(255, 193, 7, 0.5);
            outline: none;
        }

        .sidebar nav ul li a.active {
            background-color: #ffc107;
            color: #071213;
            font-weight: 700;
            border-left-color: #ffb300;
            transform: translateX(4px);
            box-shadow: 0 0 12px #ffb300;
        }

        /* Main content area */
        main {
            flex: 1;
            background: #f7faff;
            padding: 40px;
            color: #333;
            overflow-y: auto;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                position: fixed;
                bottom: 0;
                left: 0;
                width: 100%;
                height: auto;
                display: flex;
                flex-direction: row;
                justify-content: space-around;
                padding: 12px 0;
                border-right: none;
                border-top: 1px solid rgba(255, 255, 255, 0.2);
                box-shadow: 0 -3px 15px rgba(0, 0, 0, 0.3);
            }
            .sidebar h1 {
                display: none;
            }
            .sidebar nav ul {
                display: flex;
                gap: 10px;
                flex-grow: 0;
            }
            .sidebar nav ul li {
                margin-bottom: 0;
            }
            .sidebar nav ul li a {
                padding: 10px 14px;
                font-size: 0.95rem;
                border-left: none;
                border-radius: 6px;
            }
            main {
                margin-bottom: 80px;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <nav class="sidebar">
            <h1>Welcome, <?= htmlspecialchars($hospital_name) ?></h1>
            <nav>
                <ul>
                    <li><a href="dashboard.php" class="<?= basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : '' ?>">Dashboard</a></li>
                    <li><a href="update_result.php" class="<?= basename($_SERVER['PHP_SELF']) == 'update_result.php' ? 'active' : '' ?>">Update Test Result</a></li>
                    <li><a href="update_vaccination.php" class="<?= basename($_SERVER['PHP_SELF']) == 'update_vaccination.php' ? 'active' : '' ?>">Update Vaccination Status</a></li>
                     <li><a href="add_vaccine.php" class="<?= basename($_SERVER['PHP_SELF']) == 'update_vaccination.php' ? 'active' : '' ?>">Add vaccine</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </nav>
        <main>
            <h1>Hospital Dashboard</h1>
            <p>Select an option from the sidebar to manage your hospital data.</p>
        </main>
    </div>
</body>
</html>
 