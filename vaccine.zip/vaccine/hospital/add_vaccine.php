<?php
session_start();
include('../config/db.php');

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $vaccine_name = trim($_POST['vaccine_name']);
    $availability = trim($_POST['availability']);

    if (empty($vaccine_name) || empty($availability)) {
        $message = "Please fill in all fields.";
    } else {
        // Insert vaccine record
        $stmt = $conn->prepare("INSERT INTO vaccines (vaccine_name, availability) VALUES (?, ?)");
        $stmt->bind_param("ss", $vaccine_name, $availability);

        if ($stmt->execute()) {
            $message = "Vaccine added successfully!";
        } else {
            $message = "Error adding vaccine.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Add Vaccine</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #071213, #66a6ff);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            color: white;
        }
        .form-wrapper {
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(16px);
            border-radius: 16px;
            padding: 30px 25px;
            max-width: 400px;
            width: 100%;
            box-shadow: 0 8px 32px rgba(0,0,0,0.3);
        }
        h2 {
            text-align: center;
            margin-bottom: 25px;
            font-weight: 700;
        }
        label {
            margin: 12px 0 6px;
            display: block;
            font-weight: 600;
        }
        input[type="text"] {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: none;
            font-size: 1rem;
            margin-bottom: 10px;
            background-color: rgba(255,255,255,0.85);
            color: #333;
        }
        input[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #ffc107;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 1rem;
            color: #000;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        input[type="submit"]:hover {
            background-color: #e0a800;
        }
        .message {
            margin-bottom: 15px;
            padding: 10px;
            background-color: rgba(255,255,255,0.9);
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 8px;
            font-weight: 500;
            text-align: center;
        }
    </style>
</head>
<body>
<div class="form-wrapper">
    <h2>Add New Vaccine</h2>

    <?php if ($message): ?>
        <div class="message"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <form method="POST">
        <label for="vaccine_name">Vaccine Name</label>
        <input type="text" name="vaccine_name" id="vaccine_name" required />

        <label for="availability">Availability</label>
        <input type="text" name="availability" id="availability" required placeholder="e.g. Available, Out of Stock" />

        <input type="submit" value="Add Vaccine" />
    </form>
</div>
</body>
</html>
