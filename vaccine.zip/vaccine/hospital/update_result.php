<?php
session_start();
include('../config/db.php');

if (!isset($_SESSION['hospital_logged_in'])) {
    header("Location: login.php");
    exit;
}

$hospital_id = $_SESSION['hospital_id'];
$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_email = $_POST['email'];
    $test_result = $_POST['test_result'];
    $test_date = $_POST['test_date'];

    $stmt = $conn->prepare("SELECT id FROM patient WHERE email = ?");
    $stmt->bind_param("s", $patient_email);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows == 1) {
        $patient = $res->fetch_assoc();
        $patient_id = $patient['id'];

        $stmt = $conn->prepare("SELECT * FROM covid_tests WHERE patient_id = ? AND hospital_id = ?");
        $stmt->bind_param("ii", $patient_id, $hospital_id);
        $stmt->execute();
        $result_check = $stmt->get_result();

        if ($result_check->num_rows > 0) {
            $stmt = $conn->prepare("UPDATE covid_tests SET test_result = ?, test_date = ? WHERE patient_id = ? AND hospital_id = ?");
            $stmt->bind_param("ssii", $test_result, $test_date, $patient_id, $hospital_id);
            $stmt->execute();
            $message = "✅ Test result updated successfully.";
        } else {
            $stmt = $conn->prepare("INSERT INTO covid_tests (patient_id, hospital_id, test_result, test_date) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iiss", $patient_id, $hospital_id, $test_result, $test_date);
            $stmt->execute();
            $message = "✅ Test result added successfully.";
        }
    } else {
        $message = "❌ Patient email not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Test Result</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            padding: 0;
            margin: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #071213, #4a90e2);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 40px 20px;
            color: white;
        }

        .container {
            background: rgba(255, 255, 255, 0.08);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            padding: 40px 30px;
            border-radius: 16px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.4);
            width: 100%;
            max-width: 500px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 1.8rem;
            font-weight: 700;
        }

        .message {
            background-color: rgba(255, 255, 255, 0.15);
            padding: 12px 18px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 600;
            backdrop-filter: blur(10px);
            color: #fff;
            border-left: 4px solid #ffc107;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 8px;
            font-weight: 600;
            font-size: 0.95rem;
        }

        input[type="email"],
        input[type="date"],
        select {
            padding: 12px;
            margin-bottom: 20px;
            border: none;
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.15);
            color: #fff;
            font-size: 1rem;
            outline: none;
            transition: background 0.3s ease;
        }

        input[type="email"]::placeholder,
        select,
        input[type="date"] {
            color: #ddd;
        }

        input[type="email"]:focus,
        input[type="date"]:focus,
        select:focus {
            background: rgba(255, 255, 255, 0.25);
        }

        input[type="submit"] {
            padding: 14px;
            background-color: #ffc107;
            border: none;
            border-radius: 8px;
            font-weight: 700;
            font-size: 1rem;
            cursor: pointer;
            transition: background-color 0.3s ease;
            color: #000;
        }

        input[type="submit"]:hover {
            background-color: #e0a800;
        }

        a {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #ffc107;
            text-decoration: none;
            font-weight: 600;
        }

        a:hover {
            text-decoration: underline;
        }

        @media (max-width: 500px) {
            .container {
                padding: 30px 20px;
            }

            h2 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Update COVID Test Result</h2>
    <?php if ($message): ?>
        <div class="message"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <form method="POST">
        <label for="email">Patient Email</label>
        <input type="email" id="email" name="email" placeholder="patient@example.com" required>

        <label for="test_result">Test Result</label>
        <select id="test_result" name="test_result" required>
            <option value="Positive">Positive</option>
            <option value="Negative">Negative</option>
            <option value="Not Tested">Not Tested</option>
        </select>

        <label for="test_date">Test Date</label>
        <input type="date" id="test_date" name="test_date" required>

        <input type="submit" value="Update Result">
    </form>
    <a href="dashboard.php">← Back to Dashboard</a>
</div>
</body>
</html>
