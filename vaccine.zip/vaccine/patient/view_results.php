<?php
session_start();
include('../config/db.php');

if (!isset($_SESSION['patient_logged_in'])) {
    header("Location: login.php");
    exit;
}

$patient_id = $_SESSION['patient_id'];

// Fetch test results
$test_results = $conn->prepare("
    SELECT h.name AS hospital_name, ct.test_result, ct.test_date 
    FROM covid_tests ct 
    JOIN hospital h ON ct.hospital_id = h.id 
    WHERE ct.patient_id = ?
");
$test_results->bind_param("i", $patient_id);
$test_results->execute();
$test_result_data = $test_results->get_result();

// Fetch vaccination records
$vaccinations = $conn->prepare("
    SELECT h.name AS hospital_name, v.vaccine_name, v.status, v.vaccination_date 
    FROM vaccinations v 
    JOIN hospital h ON v.hospital_id = h.id 
    WHERE v.patient_id = ?
");
$vaccinations->bind_param("i", $patient_id);
$vaccinations->execute();
$vaccination_data = $vaccinations->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Results</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #071213, #66a6ff);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 40px 20px;
        }

        .container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border-radius: 16px;
            padding: 30px 40px;
            width: 100%;
            max-width: 900px;
            color: white;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        h2 {
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 16px;
            border-left: 4px solid #ffc107;
            padding-left: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
            background-color: rgba(255, 255, 255, 0.05);
            border-radius: 12px;
            overflow: hidden;
        }

        th, td {
            padding: 14px 16px;
            text-align: left;
        }

        thead {
            background-color: rgba(255, 255, 255, 0.15);
        }

        th {
            font-weight: 600;
            color: #ffc107;
        }

        tr:nth-child(even) {
            background-color: rgba(255, 255, 255, 0.07);
        }

        tr:hover {
            background-color: rgba(255, 255, 255, 0.15);
        }

        td {
            color: #fff;
        }

        a {
            display: inline-block;
            margin-top: 10px;
            text-decoration: none;
            color: #ffc107;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        a:hover {
            color: white;
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .container {
                padding: 20px;
            }

            table, th, td {
                font-size: 0.95rem;
            }

            h2 {
                font-size: 1.3rem;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h2>COVID Test Results</h2>
    <table>
        <thead>
            <tr>
                <th>Hospital</th>
                <th>Test Result</th>
                <th>Test Date</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($test_result_data->num_rows > 0): ?>
                <?php while ($row = $test_result_data->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['hospital_name']) ?></td>
                        <td><?= htmlspecialchars($row['test_result']) ?></td>
                        <td><?= htmlspecialchars($row['test_date']) ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="3">No test results found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <h2>Vaccination Records</h2>
    <table>
        <thead>
            <tr>
                <th>Hospital</th>
                <th>Vaccine Name</th>
                <th>Status</th>
                <th>Vaccination Date</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($vaccination_data->num_rows > 0): ?>
                <?php while ($row = $vaccination_data->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['hospital_name']) ?></td>
                        <td><?= htmlspecialchars($row['vaccine_name']) ?></td>
                        <td><?= htmlspecialchars($row['status']) ?></td>
                        <td><?= htmlspecialchars($row['vaccination_date']) ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="4">No vaccination records found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <a href="dashboard.php">← Back to Dashboard</a>
</div>
</body>
</html>
