<?php
session_start();
include('../config/db.php');

if (!isset($_SESSION['patient_logged_in'])) {
    header("Location: login.php");
    exit;
}

$patient_id = $_SESSION['patient_id'];
$patient_name = $_SESSION['patient_name'];
$message = "";


$hospitals = $conn->query("SELECT * FROM hospital WHERE approved = 1");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $hospital_id = intval($_POST['hospital_id']);
    $appointment_date = $_POST['appointment_date'];

    // Check if already booked on the same date
    $stmt = $conn->prepare("SELECT * FROM bookings WHERE patient_id = ? AND appointment_date = ?");
    $stmt->bind_param("is", $patient_id, $appointment_date);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        $message = "You already have an appointment on this date.";
    } else {
        $stmt = $conn->prepare("INSERT INTO bookings (patient_id, hospital_id, appointment_date) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $patient_id, $hospital_id, $appointment_date);
        if ($stmt->execute()) {
            $message = "Appointment booked successfully. Wait for approval.";
        } else {
            $message = "Error booking appointment.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book Appointment</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #071213, #66a6ff);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .form-wrapper {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border-radius: 16px;
            padding: 40px 30px;
            max-width: 500px;
            width: 100%;
            color: white;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            font-size: 1.8rem;
            font-weight: 700;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin: 12px 0 6px;
            font-weight: 600;
        }

        select,
        input[type="date"],
        input[type="submit"] {
            padding: 12px;
            border-radius: 8px;
            border: none;
            font-size: 1rem;
            margin-bottom: 10px;
        }

        select,
        input[type="date"] {
            background-color: rgba(255, 255, 255, 0.85);
            color: #333;
        }

        input[type="submit"] {
            background-color: #ffc107;
            color: #000;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #e0a800;
            cursor: pointer;
        }

        .message {
            margin-bottom: 20px;
            padding: 12px;
            background-color: rgba(255, 255, 255, 0.9);
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 8px;
            font-weight: 500;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            text-decoration: none;
            color: #fff;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        .back-link:hover {
            color: #ffc107;
        }

        @media (max-width: 600px) {
            .form-wrapper {
                padding: 30px 20px;
            }

            h2 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
<div class="form-wrapper">
    <h2>Book Appointment</h2>

    <?php if ($message): ?>
        <div class="message"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <form method="POST">
        <label>Select Hospital</label>
        <select name="hospital_id" required>
            <?php while ($row = $hospitals->fetch_assoc()): ?>
                <option value="<?= $row['id'] ?>">
                    <?= htmlspecialchars($row['name']) ?> - <?= htmlspecialchars($row['location']) ?>
                </option>
            <?php endwhile; ?>
        </select>

        <label>Appointment Date</label>
        <input type="date" name="appointment_date" required />

        <input type="submit" value="Book Appointment" />
    </form>

    <a class="back-link" href="dashboard.php">← Back to Dashboard</a>
</div>
</body>
</html>
