<?php
include('../config/db.php');
$email = $_GET['email'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>COVID Report Checker</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #071213, #66a6ff);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .form-wrapper {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border-radius: 16px;
            padding: 40px 30px;
            max-width: 500px;
            width: 100%;
            color: white;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            font-size: 1.8rem;
            font-weight: 700;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin: 12px 0 6px;
            font-weight: 600;
        }

        input[type="email"],
        input[type="submit"] {
            padding: 12px;
            border-radius: 8px;
            border: none;
            font-size: 1rem;
            margin-bottom: 10px;
        }

        input[type="email"] {
            background-color: rgba(255, 255, 255, 0.85);
            color: #333;
        }

        input[type="submit"] {
            background-color: #ffc107;
            color: #000;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #e0a800;
            cursor: pointer;
        }

        .message {
            margin-bottom: 20px;
            padding: 12px;
            background-color: rgba(255, 255, 255, 0.9);
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 8px;
            font-weight: 500;
            text-align: center;
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            text-decoration: none;
            color: #fff;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        .back-link:hover {
            color: #ffc107;
        }

        @media (max-width: 600px) {
            .form-wrapper {
                padding: 30px 20px;
            }

            h2 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>

    <div class="form-wrapper">
        <h2>Check Your COVID Report</h2>
        <form method="GET" action="">
            <label for="email">Enter your email:</label>
            <input type="email" name="email" id="email" required value="<?php echo htmlspecialchars($email); ?>">
            <input type="submit" value="View Report">
        </form>

        <?php
        if (!empty($email)) {
            $stmt = $conn->prepare("SELECT r.report_file, r.uploaded_at 
                                    FROM patient p 
                                    JOIN covid_reports r ON p.id = r.patient_id 
                                    WHERE p.email = ? 
                                    ORDER BY r.uploaded_at DESC LIMIT 1");

            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                echo "<div class='message'>";
                echo "<strong>Report Date:</strong> " . htmlspecialchars($row['uploaded_at']) . "<br>";
                echo "<a class='back-link' href='download_report.php?email=" . urlencode($email) . "'>Download Report</a>";
                echo "</div>";
            } else {
                echo "<div class='message'>No report found for this email.</div>";
            }

            $stmt->close();
        }
        ?>
    </div>

</body>
</html>
