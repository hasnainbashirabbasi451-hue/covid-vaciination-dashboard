<?php
include('../config/db.php');
$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $address = $_POST['address'];
    $location = $_POST['location'];

    $stmt = $conn->prepare("SELECT * FROM patient WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        $error = "Email already registered.";
    } else {
        $passHash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO patient (name, email, password, address, location) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $name, $email, $passHash, $address, $location);
        if ($stmt->execute()) {
            $success = "Registration successful! Please login.";
        } else {
            $error = "Error in registration.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Patient Registration</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet" />
    <style>
        /* Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #071213, #66a6ff);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            color: white;
        }

        .container {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(14px);
            -webkit-backdrop-filter: blur(14px);
            border-radius: 16px;
            padding: 40px 50px;
            max-width: 450px;
            width: 100%;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.12);
            text-align: center;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        h2 {
            font-weight: 700;
            font-size: 2rem;
            margin-bottom: 30px;
        }

        form {
            display: flex;
            flex-direction: column;
            text-align: left;
        }

        label {
            font-weight: 600;
            margin-bottom: 6px;
            margin-top: 20px;
            font-size: 0.95rem;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"],
        textarea {
            padding: 12px 15px;
            border-radius: 8px;
            border: none;
            outline: none;
            font-size: 1rem;
            transition: box-shadow 0.3s ease;
            background: rgba(255, 255, 255, 0.25);
            color: white;
            font-weight: 500;
            box-shadow: inset 0 0 8px rgba(255, 255, 255, 0.3);
            resize: vertical;
        }

        textarea {
            min-height: 80px;
            font-family: 'Inter', sans-serif;
        }

        input::placeholder,
        textarea::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="password"]:focus,
        textarea:focus {
            box-shadow: 0 0 8px 2px #ffc107;
            background: rgba(255, 255, 255, 0.35);
        }

        input[type="submit"] {
            margin-top: 30px;
            padding: 14px;
            border-radius: 10px;
            border: none;
            font-weight: 700;
            font-size: 1.1rem;
            cursor: pointer;
            background: #007bff;
            color: white;
            box-shadow: 0 5px 15px rgba(0,123,255,0.4);
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
        }

        input[type="submit"]:hover {
            background: #0056b3;
            box-shadow: 0 8px 20px rgba(0,86,179,0.7);
        }

        .error,
        .success {
            padding: 14px;
            border-radius: 8px;
            font-weight: 600;
            margin-bottom: 20px;
            box-shadow: 0 0 10px rgba(255, 255, 255, 0.4);
        }

        .error {
            background: rgba(255, 0, 0, 0.25);
            color: #ffdddd;
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5);
        }

        .success {
            background: rgba(40, 180, 40, 0.25);
            color: #d4f8d4;
            box-shadow: 0 0 10px rgba(40, 180, 40, 0.5);
        }

        a {
            display: inline-block;
            margin-top: 25px;
            font-weight: 600;
            color: #ffc107;
            text-decoration: none;
            transition: color 0.3s ease;
            font-size: 0.95rem;
            text-align: center;
        }

        a:hover {
            color: white;
        }

        @media (max-width: 480px) {
            .container {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Patient Registration</h2>
    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <form method="POST" novalidate>
        <label for="name">Name</label>
        <input type="text" id="name" name="name" placeholder="Your full name" required />

        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="you@example.com" required />

        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="Create a password" required />

        <label for="address">Address</label>
        <textarea id="address" name="address" placeholder="Your address" required></textarea>

        <label for="location">Location</label>
        <input type="text" id="location" name="location" placeholder="City or region" required />

        <input type="submit" value="Register" />
    </form>
    <a href="login.php">Already registered? Login here</a>
</div>
</body>
</html>
