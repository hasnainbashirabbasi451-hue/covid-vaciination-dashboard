<?php
include('../config/db.php');

if (!isset($_GET['email']) || empty($_GET['email'])) {
    die('Email is required.');
}

$email = $_GET['email'];
$stmt = $conn->prepare("SELECT r.report_file 
                        FROM patient p 
                        JOIN covid_reports r ON p.id = r.patient_id 
                        WHERE p.email = ? 
                        ORDER BY r.uploaded_at DESC 
                        LIMIT 1");

$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die('No report found for this email.');
}

$row = $result->fetch_assoc();
$filename = basename($row['report_file']); 
$filepath = "../reports/" . $filename;

// Check file exists
if (!file_exists($filepath)) {
  
}

// Send headers to trigger file download
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize($filepath));


ob_clean();
flush();
readfile($filepath);
exit;
