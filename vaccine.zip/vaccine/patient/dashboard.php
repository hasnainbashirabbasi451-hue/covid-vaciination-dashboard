<?php
session_start();
include('../config/db.php');

if (!isset($_SESSION['patient_logged_in'])) {
    header("Location: login.php");
    exit;
}

$patient_id = $_SESSION['patient_id'];
$patient_name = $_SESSION['patient_name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Patient Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #66a6ff;
            --accent-color: #ffc107;
            --bg-dark: #071213;
            --glass: rgba(255, 255, 255, 0.1);
            --text-light: #f0f0f0;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, var(--bg-dark), var(--primary-color));
            min-height: 100vh;
            display: flex;
        }

        .container {
            display: flex;
            width: 100%;
        }

        .sidebar {
            width: 250px;
            background: var(--glass);
            backdrop-filter: blur(18px);
            padding: 40px 25px;
            color: var(--text-light);
            box-shadow: 10px 0 30px rgba(0, 0, 0, 0.3);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            border-right: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar h1 {
            font-size: 1.8rem;
            font-weight: 700;
            text-align: center;
            color: var(--accent-color);
            margin-bottom: 40px;
        }

        .sidebar ul {
            list-style: none;
        }

        .sidebar ul li {
            margin-bottom: 20px;
        }

        .sidebar ul li a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 18px;
            text-decoration: none;
            color: white;
            font-weight: 600;
            border-radius: 12px;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.05);
        }

        .sidebar ul li a:hover {
            background: var(--accent-color);
            color: #000;
            transform: translateX(5px);
        }

        main {
            flex: 1;
            padding: 60px 80px;
            background-color: #f9fbff;
            color: #333;
            position: relative;
            overflow-y: auto;
        }

        main::before {
            content: "";
            position: absolute;
            top: 10%;
            right: -10%;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, rgba(102, 166, 255, 0.2), transparent);
            z-index: 0;
            transform: rotate(25deg);
        }

        h1 {
            font-size: 2.5rem;
            color: #222;
            margin-bottom: 20px;
            animation: fadeInDown 1s ease-out;
        }

        p, li {
            font-size: 1.1rem;
            line-height: 1.6;
            color: #444;
            z-index: 1;
        }

        ul {
            margin-top: 20px;
            padding-left: 20px;
        }

        li::before {
            content: '🌟';
            margin-right: 10px;
        }

        @keyframes fadeInDown {
            0% {
                opacity: 0;
                transform: translateY(-30px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Responsive */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }

            .sidebar {
                flex-direction: row;
                width: 100%;
                height: auto;
                padding: 10px;
                justify-content: space-around;
                position: fixed;
                bottom: 0;
                left: 0;
                z-index: 100;
                border-right: none;
                border-top: 1px solid rgba(255,255,255,0.1);
            }

            .sidebar h1 {
                display: none;
            }

            .sidebar ul {
                display: flex;
                flex-direction: row;
                gap: 10px;
            }

            .sidebar ul li {
                margin: 0;
            }

            .sidebar ul li a {
                font-size: 0.9rem;
                padding: 10px 12px;
            }

            main {
                padding: 100px 20px 80px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <nav class="sidebar">
        <div>
            <h1>🩺 Patient Details</h1>
            <ul>
                <li><a href="book_appointment.php">📅 Book</a></li>
                <li><a href="view_results.php">📄 Results</a></li>
                 <li><a href="get_report.php">📄 Get reports</a></li>
                 <li><a href="view_vaccines.php">View a vaccine</a></li>
                <li><a href="logout.php">🚪 Logout</a></li>
            </ul>
        </div>
    </nav>

    <main>
        <h1>Welcome, <?= htmlspecialchars($patient_name) ?> 👋</h1>
        <p>Your personal health dashboard is ready. Here's what you can do:</p>
        <ul>
            <li>Schedule appointments with verified hospitals</li>
            <li>Check your COVID test & vaccine records</li>
            <li>Securely manage your account</li>
        </ul>
        <p style="margin-top: 30px;">
            Need help? Contact our support team or visit the nearest hospital in your network.
        </p>
    </main>
</div>
</body>
</html>
