<?php
session_start();
include('../config/db.php');

// Optional: Restrict to logged-in patients
if (!isset($_SESSION['patient_logged_in'])) {
    header("Location: login.php");
    exit;
}

$vaccines = $conn->query("SELECT * FROM vaccines ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Available Vaccines</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #071213, #66a6ff);
            min-height: 100vh;
            padding: 20px;
            color: white;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: rgba(255,255,255,0.1);
            padding: 30px;
            border-radius: 15px;
            backdrop-filter: blur(16px);
        }
        h2 {
            text-align: center;
            margin-bottom: 25px;
            font-weight: 700;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: rgba(255,255,255,0.2);
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid rgba(255,255,255,0.3);
        }
        th {
            background-color: rgba(0,0,0,0.2);
            font-weight: 600;
        }
        tr:hover {
            background-color: rgba(255,255,255,0.1);
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            text-decoration: none;
            color: #fff;
            font-weight: 600;
        }
        .back-link:hover {
            color: #ffc107;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Available Vaccines</h2>
    <?php if ($vaccines->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Vaccine Name</th>
                    <th>Availability</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $vaccines->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['vaccine_name']) ?></td>
                        <td><?= htmlspecialchars($row['availability']) ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No vaccines found.</p>
    <?php endif; ?>
    <a class="back-link" href="dashboard.php">← Back to Dashboard</a>
</div>
</body>
</html>
